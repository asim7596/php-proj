<?php 
$con=mysqli_connect("localhost","root","","user");

 $sq="delete from user_registration where id='$_REQUEST[id]'";
mysqli_query($con, $sq);
header('location:view_user.php');
?>