
<?php
$con=mysqli_connect("localhost","root","","user");

?>


<table border="1px">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Contact</th>
        <th>Email</th>
        <th>Password</th>        
        <th>Registration Date</th>
        <th>Images</th>
        <th>Action</th>

    <?php


    
    $sq="select * from user_registration";
    $qu= mysqli_query($con, $sq);
  
    while($f= mysqli_fetch_assoc($qu))
    {
        ?>
    <tr>
        <td><?php echo $f['id']; ?></td>
        <td><?php echo $f['first_name'] . ' ' . $f['last_name'] ; ?></td>
        <td><?php echo $f['contact']; ?></td>
        <td><?php echo $f['email']; ?></td>
        <td><?php echo $f['password']; ?></td>
         <td><?php echo $f['regis_date']; ?></td>
        <td><img src="<?php echo $f['image']; ?>" width="100px" height="100px"></td>        
       
        
        <td><!--<a href="edit2.php">Edit</a>-->
<a href="edit_user.php?id=<?php echo $f['id'] ?>">Edit</a>
<a href="delete.php?id=<?php echo $f['id'] ?>">Delete</a>
        </td>
    </tr>
    <?php
        }
    ?>
</table>
