<?php 
$con=mysqli_connect("localhost","root","","user");

$sq="select * from user_registration where id='$_REQUEST[id]'";
$qu=mysqli_query($con,$sq);
$f= mysqli_fetch_assoc($qu);

if(isset($_POST['sub']))
{
    $first=$_POST['first_name'];
    $last=$_POST['last_name'];
    $contact=$_POST['contact'];
    $email=$_POST['email'];
    $password=$_POST['password'];
   

  if($_FILES['f1']['name'])
 {
       move_uploaded_file($_FILES['f1']['tmp_name'],"image/".$_FILES['f1']['name']);
       $img="image/".$_FILES['f1']['name'];
}
 else 
 {
 $img=$_POST['img1'];    
 }
$sq="update user_registration set first_name='$first',last_name='$last',password='$password',contact='$contact',email='$email',image='$img' where id='$_REQUEST[id]'";
 $qu=mysqli_query($con,$sq);
 header('location:view_user.php');
}

?>
<html>
    <body>
        <form method="post" enctype="multipart/form-data">
            <table>
                
                <tr><td>First Name :</td><td><input type="text" name="first_name" placeholder="enter first name" value="<?php echo $f['first_name']; ?>"required ></td></tr>
                <tr><td>Last Name :</td><td><input type="text" name="last_name" placeholder="enter last name" value="<?php echo $f['last_name']; ?>" required></td></tr>
                <tr><td>Contact :</td><td><input type="number" name="contact" placeholder="enter contact" value="<?php echo $f['contact']; ?>" required></td></tr>
                <tr><td>Email :</td><td><input type="email" name="email" placeholder="enter email" value="<?php echo $f['email']; ?>" required></td></tr>
                <tr><td>Password :</td><td><input type="password" name="password" placeholder="enter password" value="<?php echo $f['password']; ?>" required></td></tr>
                <tr><td>images :</td>
                  <td>
                      <img src="<?php echo $f['image']; ?>"width="100px" height="100px">
                           <input type="file" name="f1">
                      <input type="hidden" name="img1"value="<?php echo $f['image']; ?>" >
                  </td></tr> 
                
                <tr><td><input type="submit" value="Update" name="sub"></td>
                    <td><input type="reset" value="Reset" name="res"></td>
             </tr>
            </table>
        </form>
              
    </body>
</html>
