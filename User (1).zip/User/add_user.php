<?php 
$con=mysqli_connect("localhost","root","","user");
if(isset($_POST['sub']))
{
    $first=$_POST['first_name'];
    $last=$_POST['last_name'];
    $contact=$_POST['contact'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $date=$_POST['date'];

   if($_FILES['f1']['name'])
   {
       move_uploaded_file($_FILES['f1']['tmp_name'],"image/".$_FILES['f1']['name']);
       $img="image/".$_FILES['f1']['name'];
   }
   
    $sq="insert into user_registration(first_name,last_name,password,email,contact,regis_date,image)values('$first','$last','$password','$email','$contact','$date','$img')";
    $qu=mysqli_query($con,$sq);
}
?>
<html>
    <body>
        <form method="post" enctype="multipart/form-data">
            <table>
                
                <tr><td>First Name :</td><td><input type="text" name="first_name" placeholder="enter first name" required ></td></tr>
                <tr><td>Last Name :</td><td><input type="text" name="last_name" placeholder="enter last name" required></td></tr>
                <tr><td>Contact :</td><td><input type="number" name="contact" placeholder="enter contact" required></td></tr>
                <tr><td>Email :</td><td><input type="email" name="email" placeholder="enter email" required></td></tr>
                <tr><td>Password :</td><td><input type="password" name="password" placeholder="enter password" required></td></tr>
                <tr><td>Image :</td><td><input type="file" name="f1" required></td></tr>
                <tr><td>Registration Date :</td><td><input type="date" name="date" placeholder="enter DOB" required></td></tr>
                
                <tr><td><input type="submit" value="submit" name="sub"></td>
                    <td><input type="reset" value="reset" name="res"></td>
             </tr>
            </table>
        </form>
              
    </body>
</html>
