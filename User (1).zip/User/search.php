
<?php
$con=mysqli_connect("localhost","root","","user");

?>
<form method="post">
    <table>
    <tr>
        <td>
            <input type="text" name="search"></td>
        <td> <input type="submit" value="search" name="sub"></td>
    </tr>
    </table>
</form>

<table border="1px">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Contact</th>
        <th>Email</th>
        <th>Password</th>        
        <th>Registration Date</th>
        <th>Images</th>
        <th>Action</th>

    <?php
//    if(isset($_POST['sub']))
//{
        if (!empty($_REQUEST['search'])) {
    $search=$_POST['search'];

    
    $sq="select * from user_registration where first_name = '".$search."' or last_name = '".$search."'";
    $qu= mysqli_query($con, $sq);
    if(mysqli_num_rows($qu)>0)
        {
    while($f= mysqli_fetch_assoc($qu))
    {
        ?>
    <tr>
        <td><?php echo $f['id']; ?></td>
        <td><?php echo $f['first_name'] . ' ' . $f['last_name'] ; ?></td>
        <td><?php echo $f['contact']; ?></td>
        <td><?php echo $f['email']; ?></td>
        <td><?php echo $f['password']; ?></td>
         <td><?php echo $f['regis_date']; ?></td>
        <td><img src="<?php echo $f['image']; ?>" width="100px" height="100px"></td>        
       
        
        <td><!--<a href="edit2.php">Edit</a>-->
<a href="edit_user.php?id=<?php echo $f['id'] ?>">Edit</a>
<a href="delete.php?id=<?php echo $f['id'] ?>">Delete</a>
        </td>
    </tr>
    <?php
        } }
        else
        {
            echo "<h2><center>User Not Found!</center></h2>";
        }}
    ?>
</table>
